@if (websiteInfo('trader_mode') == 'enabled' && isAddonEnabled('cryptotrading'))
    @include('themes.custom_algo.user.trade.trade.index')    
@else
    @include('themes.custom_algo.user.dashboard-content')
@endif